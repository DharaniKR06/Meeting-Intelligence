/**
 * Node.js Test Verification Runner
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

import { extractMeetingItems } from '../src/engine/extraction.js';
import { resolveDeterministicDate } from '../src/engine/date_resolver.js';
import { resolveDeterministicOwner } from '../src/engine/owner_resolver.js';
import { MockTaskAPI } from '../src/engine/task_api_mock.js';
import { runFullEvaluation } from '../src/engine/evaluator.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const directory = JSON.parse(fs.readFileSync(path.join(__dirname, '../src/data/participant_directory.json'), 'utf8'));
const glossary = JSON.parse(fs.readFileSync(path.join(__dirname, '../src/data/project_glossary.json'), 'utf8'));
const testMeetings = JSON.parse(fs.readFileSync(path.join(__dirname, '../src/data/test_meetings.json'), 'utf8'));
const groundTruth = JSON.parse(fs.readFileSync(path.join(__dirname, '../src/data/ground_truth.json'), 'utf8'));

console.log('=== STARTING MEETING INTELLIGENCE PIPELINE VERIFICATION ===');

const taskApi = new MockTaskAPI();
const evalResults = runFullEvaluation(testMeetings, groundTruth, directory, glossary, taskApi);

console.log('\n--- QUANTITATIVE EVALUATION RESULTS ---');
console.log(`Action Precision:             ${evalResults.overall.actionCommitmentsPrecision}`);
console.log(`Action Recall:                ${evalResults.overall.actionCommitmentsRecall}`);
console.log(`Owner Resolution Accuracy:    ${evalResults.overall.ownerAccuracyPct}%`);
console.log(`Due-Date Resolution Accuracy: ${evalResults.overall.dueDateAccuracyPct}%`);
console.log(`Unsupported Item Rate:        ${evalResults.overall.unsupportedItemRatePct}%`);
console.log(`Confirmation Effort Score:    ${evalResults.overall.confirmationEffortScore}`);

console.log('\n--- VERIFYING HARD TASK API SECURITY CONSTRAINT ---');
try {
  taskApi.createTask({
    title: 'Illegal task without human confirmation',
    humanConfirmed: false // Should throw security exception
  });
  console.error('FAIL: Unconfirmed task was allowed!');
} catch (err) {
  console.log(`SUCCESS: Unconfirmed task was correctly rejected with message: "${err.message}"`);
}

console.log('\n--- VERIFYING IDEMPOTENCY & DUPLICATE CREATION PREVENTION ---');
const meeting1 = testMeetings[0];
const items = extractMeetingItems(meeting1, directory, glossary);
const actionItem = items.find(i => i.type === 'ACTION_COMMITMENT');

if (actionItem) {
  const payload = {
    meetingId: meeting1.id,
    sourceItemId: actionItem.id,
    title: actionItem.summary,
    ownerId: actionItem.owner.participant.id,
    ownerName: actionItem.owner.participant.name,
    dueDate: actionItem.dueDate.isoDate,
    humanConfirmed: true,
    confirmationToken: 'CONF-TOK-TEST-1',
    idempotencyKey: actionItem.idempotencyKey
  };

  const res1 = taskApi.createTask(payload);
  console.log(`First task creation status: ${res1.status} (Task #${res1.task.id})`);

  const res2 = taskApi.createTask(payload);
  console.log(`Second idempotent creation attempt status: ${res2.status} (${res2.message})`);
}

console.log('\n=== PIPELINE VERIFICATION COMPLETE ===');
