/**
 * Deterministic Owner Resolver Module
 * Resolves candidate owners against the authoritative Participant Directory.
 * Enforces strict safety rules against role-only inference, pronoun ambiguity, and low diarization confidence.
 */

import { UnresolvedState } from './schema.js';

export function resolveDeterministicOwner(candidateText, speakerSegment, participantDirectory, meetingParticipants = []) {
  // Rule 1: Check diarization confidence of the speaker segment
  if (speakerSegment && typeof speakerSegment.confidence === 'number' && speakerSegment.confidence < 0.70) {
    return {
      status: UnresolvedState.UNRESOLVED_OWNER,
      participant: null,
      rawText: candidateText || speakerSegment.speaker,
      confidence: speakerSegment.confidence,
      reason: `Low diarization/speaker confidence (${speakerSegment.confidence}). Requires manual verification.`
    };
  }

  const rawCandidate = (candidateText || speakerSegment?.speaker || '').trim();
  if (!rawCandidate) {
    return {
      status: UnresolvedState.UNRESOLVED_OWNER,
      participant: null,
      rawText: '',
      confidence: 0,
      reason: 'No owner candidate specified in transcript'
    };
  }

  const lowerCandidate = rawCandidate.toLowerCase();

  // Rule 2: Ambiguous Pronoun Check ("he", "she", "they")
  if (['he', 'him', 'his', 'she', 'her', 'they', 'them'].includes(lowerCandidate)) {
    // Check present male/female participants in meeting context
    const presentParticipants = participantDirectory.filter(p => meetingParticipants.includes(p.id));
    return {
      status: UnresolvedState.UNRESOLVED_OWNER,
      participant: null,
      rawText: rawCandidate,
      confidence: 0.3,
      reason: `Ambiguous pronoun '${rawCandidate}' with multiple participants in meeting context (${presentParticipants.map(p=>p.name).join(', ')})`
    };
  }

  // Rule 3: Role-only Inference Check ("DBA", "the DBA", "frontend team", "architect")
  const roleKeywords = ['dba', 'database administrator', 'qa team', 'frontend team', 'architect'];
  if (roleKeywords.some(rk => lowerCandidate.includes(rk))) {
    // Search if candidate explicitly includes a person's name or is strictly role-only
    const matchesPersonName = participantDirectory.some(p => 
      p.aliases.some(alias => lowerCandidate.includes(alias.toLowerCase()))
    );

    if (!matchesPersonName) {
      return {
        status: UnresolvedState.UNRESOLVED_OWNER,
        participant: null,
        rawText: rawCandidate,
        confidence: 0.4,
        reason: `Role-based reference '${rawCandidate}' without explicit participant name. Auto-assignment strictly forbidden.`
      };
    }
  }

  // Rule 4: Match against Directory by Full Name, Alias, or Email
  for (const person of participantDirectory) {
    // Check exact name match
    if (person.name.toLowerCase() === lowerCandidate) {
      return {
        status: 'RESOLVED',
        participant: person,
        rawText: rawCandidate,
        confidence: 1.0,
        reason: `Matched exact directory name: ${person.name}`
      };
    }

    // Check alias match
    for (const alias of person.aliases) {
      if (lowerCandidate.includes(alias.toLowerCase()) || alias.toLowerCase() === lowerCandidate) {
        return {
          status: 'RESOLVED',
          participant: person,
          rawText: rawCandidate,
          confidence: 0.95,
          reason: `Matched directory alias '${alias}' for ${person.name}`
        };
      }
    }

    // Check email match
    if (person.email.toLowerCase() === lowerCandidate) {
      return {
        status: 'RESOLVED',
        participant: person,
        rawText: rawCandidate,
        confidence: 1.0,
        reason: `Matched participant email ${person.email}`
      };
    }
  }

  // Rule 5: Fallback if candidate was speaker who said "I will..." or "I'll..."
  if ((lowerCandidate === 'i' || lowerCandidate === 'me' || lowerCandidate === 'self') && speakerSegment?.speaker_id) {
    const person = participantDirectory.find(p => p.id === speakerSegment.speaker_id);
    if (person) {
      return {
        status: 'RESOLVED',
        participant: person,
        rawText: speakerSegment.speaker,
        confidence: speakerSegment.confidence || 0.9,
        reason: `Resolved first-person statement to speaker '${person.name}' (${person.id})`
      };
    }
  }

  // Default: Unresolved Owner
  return {
    status: UnresolvedState.UNRESOLVED_OWNER,
    participant: null,
    rawText: rawCandidate,
    confidence: 0.2,
    reason: `Candidate '${rawCandidate}' could not be matched with high confidence in directory.`
  };
}
