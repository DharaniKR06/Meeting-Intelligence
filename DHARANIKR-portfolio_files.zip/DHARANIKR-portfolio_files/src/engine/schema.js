/**
 * Schema definitions for Meeting Intelligence Workflow System
 */

export const ItemType = {
  DECISION: 'DECISION',
  PROPOSED_OPTION: 'PROPOSED_OPTION',
  OPEN_QUESTION: 'OPEN_QUESTION',
  RISK: 'RISK',
  ACTION_COMMITMENT: 'ACTION_COMMITMENT',
  PARKING_LOT: 'PARKING_LOT'
};

export const UnresolvedState = {
  UNRESOLVED_OWNER: 'UNRESOLVED_OWNER',
  UNRESOLVED_DATE: 'UNRESOLVED_DATE'
};

export class Evidence {
  constructor({ meetingId, transcriptId, timestampStart, timestampEnd, speakerRaw, speakerId, verbatimText }) {
    this.meetingId = meetingId;
    this.transcriptId = transcriptId;
    this.timestampStart = timestampStart;
    this.timestampEnd = timestampEnd;
    this.speakerRaw = speakerRaw;
    this.speakerId = speakerId || null;
    this.verbatimText = verbatimText;
  }
}

export class Confidence {
  constructor({ diarization = 1.0, extraction = 1.0, ownerResolution = 1.0, dateResolution = 1.0 }) {
    this.diarization = diarization;
    this.extraction = extraction;
    this.ownerResolution = ownerResolution;
    this.dateResolution = dateResolution;
    this.overall = +( (diarization * 0.25 + extraction * 0.35 + ownerResolution * 0.2 + dateResolution * 0.2).toFixed(2) );
  }
}

export class ExtractedItem {
  constructor({
    id,
    type,
    summary,
    evidence,
    confidence,
    owner = null, // { id, name, role, email, status: 'RESOLVED'|'UNRESOLVED_OWNER', reason: string }
    dueDate = null, // { isoDate: string, rawText: string, status: 'RESOLVED'|'UNRESOLVED_DATE', reason: string }
    isConditional = false,
    conditionText = null,
    linguisticCues = [],
    idempotencyKey = null,
    duplicateWarning = null
  }) {
    this.id = id;
    this.type = type;
    this.summary = summary;
    this.evidence = evidence;
    this.confidence = confidence;
    this.owner = owner;
    this.dueDate = dueDate;
    this.isConditional = isConditional;
    this.conditionText = conditionText;
    this.linguisticCues = linguisticCues;
    this.idempotencyKey = idempotencyKey;
    this.duplicateWarning = duplicateWarning;
  }
}
