/**
 * Mock Task Management API
 * Encapsulates task creation, listing, idempotency enforcement, and audit trail retrieval.
 * HARD CONSTRAINT: Rejects any task creation attempt that lacks explicit human confirmation.
 */

import { AuditLogger } from './dedup_idempotency.js';

export class MockTaskAPI {
  constructor() {
    this.tasks = [];
    this.auditLogger = new AuditLogger();
    this.idempotencyStore = new Set();
    this.taskIdCounter = 1001;
  }

  /**
   * Create Task with Hard Human Confirmation Check
   */
  createTask(payload) {
    // HARD SECURITY CONSTRAINT ENFORCEMENT
    if (!payload || payload.humanConfirmed !== true) {
      throw new Error('[SECURITY VIOLATION] Task creation rejected: Missing explicit human confirmation.');
    }

    if (!payload.confirmationToken) {
      throw new Error('[SECURITY VIOLATION] Task creation rejected: Missing confirmation token.');
    }

    // Idempotency Check
    if (payload.idempotencyKey && this.idempotencyStore.has(payload.idempotencyKey)) {
      const existing = this.tasks.find(t => t.idempotencyKey === payload.idempotencyKey);
      this.auditLogger.logEvent({
        action: 'TASK_CREATION_BLOCKED_IDEMPOTENT',
        meetingId: payload.meetingId,
        runId: payload.runId || 'RUN-01',
        itemId: payload.sourceItemId,
        taskId: existing?.id,
        confirmedBy: payload.confirmedBy,
        details: `Blocked duplicate creation for idempotency key: ${payload.idempotencyKey}`
      });
      return {
        status: 'IDEMPOTENT_SKIPPED',
        task: existing,
        message: `Task already exists with idempotency key ${payload.idempotencyKey}`
      };
    }

    const newTask = {
      id: `TSK-${this.taskIdCounter++}`,
      title: payload.title,
      ownerId: payload.ownerId,
      ownerName: payload.ownerName,
      dueDate: payload.dueDate,
      project: payload.project || 'Project Titan',
      isConditional: !!payload.isConditional,
      conditionText: payload.conditionText || null,
      evidenceQuote: payload.evidenceQuote,
      evidenceMeetingId: payload.meetingId,
      evidenceTimestamp: payload.evidenceTimestamp,
      idempotencyKey: payload.idempotencyKey,
      status: 'OPEN',
      createdAt: new Date().toISOString(),
      confirmedBy: payload.confirmedBy || 'Human Reviewer'
    };

    this.tasks.push(newTask);
    if (payload.idempotencyKey) {
      this.idempotencyStore.add(payload.idempotencyKey);
    }

    // Record Audit Log Entry
    const auditEntry = this.auditLogger.logEvent({
      action: 'TASK_CREATED',
      meetingId: payload.meetingId,
      runId: payload.runId || 'RUN-01',
      itemId: payload.sourceItemId,
      taskId: newTask.id,
      confirmedBy: payload.confirmedBy,
      details: `Created task "${newTask.title}" assigned to ${newTask.ownerName} (${newTask.ownerId}), due: ${newTask.dueDate}`
    });

    return {
      status: 'SUCCESS',
      task: newTask,
      auditEntry
    };
  }

  listTasks() {
    return [...this.tasks];
  }

  getAuditTrail() {
    return this.auditLogger.getAllLogs();
  }

  reset() {
    this.tasks = [];
    this.idempotencyStore.clear();
    this.auditLogger = new AuditLogger();
    this.taskIdCounter = 1001;
  }
}
