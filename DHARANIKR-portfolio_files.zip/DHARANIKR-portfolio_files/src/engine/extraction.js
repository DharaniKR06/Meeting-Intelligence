/**
 * Semantic NLP & Intent Frame Extraction Engine
 * Parses meeting transcripts using linguistic features, grammatical mood,
 * commitment strength scoring, conditionality clauses, sarcasm detection,
 * and code-mixed intent classification.
 */

import { ItemType, ExtractedItem, Evidence, Confidence } from './schema.js';
import { resolveDeterministicDate } from './date_resolver.js';
import { resolveDeterministicOwner } from './owner_resolver.js';
import { generateIdempotencyKey } from './dedup_idempotency.js';

export function extractMeetingItems(meetingData, participantDirectory, glossaryData) {
  const items = [];
  const transcript = meetingData.transcript || [];
  const meetingId = meetingData.id;
  const meetingDate = meetingData.date;
  const meetingParticipants = meetingData.participants_present || [];

  // Active commitment tracker for turn-taking corrections
  const activeCommitmentsMap = new Map();

  for (let i = 0; i < transcript.length; i++) {
    const seg = transcript[i];
    const text = seg.text;
    const tokens = tokenize(text);
    const semanticFrame = analyzeSemanticFrame(text, tokens);

    // 1. SARCASM & HYPERBOLE DISCARD
    if (semanticFrame.isSarcastic) {
      items.push(new ExtractedItem({
        id: `ITEM-${meetingId}-${seg.id}-SARC`,
        type: ItemType.PARKING_LOT,
        summary: `[DISCARDED - SARCASTIC HYPERBOLE] ${text}`,
        evidence: new Evidence({
          meetingId,
          transcriptId: seg.id,
          timestampStart: seg.start,
          timestampEnd: seg.end,
          speakerRaw: seg.speaker,
          speakerId: seg.speaker_id,
          verbatimText: text
        }),
        confidence: new Confidence({ diarization: seg.confidence || 0.9, extraction: 0.98 }),
        linguisticCues: [
          `Sarcasm Signal: Mocking prefix (${semanticFrame.sarcasmPrefix})`,
          `Hyperbolic Workload: (${semanticFrame.hyperbolePhrase})`,
          'Filtered from Task Pipeline'
        ],
        owner: { status: 'UNRESOLVED_OWNER', reason: 'Sarcastic hyperbole ignored' }
      }));
      continue;
    }

    // 2. MID-MEETING CORRECTION
    if (semanticFrame.isCorrection) {
      const speakerKey = seg.speaker_id || seg.speaker;
      const lastKey = Array.from(activeCommitmentsMap.keys()).reverse().find(k => k.startsWith(speakerKey));
      if (lastKey) {
        const prevItem = activeCommitmentsMap.get(lastKey);
        const newDateResolved = resolveDeterministicDate(text, meetingDate, glossaryData);
        if (newDateResolved.status === 'RESOLVED') {
          prevItem.dueDate = newDateResolved;
          prevItem.linguisticCues.push(`[Mid-Meeting Correction @ ${seg.start}]: Date updated via "${text}"`);
          prevItem.evidence.verbatimText += ` --> [CORRECTED AT ${seg.start}: "${text}"]`;
          continue;
        }
      }
    }

    // 3. DECISION CLASSIFICATION
    if (semanticFrame.primaryIntent === 'DECISION') {
      items.push(new ExtractedItem({
        id: `ITEM-${meetingId}-${seg.id}`,
        type: ItemType.DECISION,
        summary: formatSummary(text, semanticFrame.corePhrase),
        evidence: new Evidence({
          meetingId,
          transcriptId: seg.id,
          timestampStart: seg.start,
          timestampEnd: seg.end,
          speakerRaw: seg.speaker,
          speakerId: seg.speaker_id,
          verbatimText: text
        }),
        confidence: new Confidence({ diarization: seg.confidence || 0.9, extraction: 0.95 }),
        linguisticCues: [
          `Consensus Markers: [${semanticFrame.matchedKeywords.join(', ')}]`,
          `Certainty: ${semanticFrame.certaintyScore * 100}%`
        ]
      }));
    }

    // 4. ACTION COMMITMENT CLASSIFICATION
    else if (semanticFrame.primaryIntent === 'ACTION_COMMITMENT') {
      const ownerCandidate = semanticFrame.ownerCandidate || seg.speaker;
      const ownerResolved = resolveDeterministicOwner(ownerCandidate, seg, participantDirectory, meetingParticipants);
      const dateResolved = resolveDeterministicDate(text, meetingDate, glossaryData);

      const item = new ExtractedItem({
        id: `ITEM-${meetingId}-${seg.id}`,
        type: ItemType.ACTION_COMMITMENT,
        summary: formatSummary(text, semanticFrame.corePhrase),
        evidence: new Evidence({
          meetingId,
          transcriptId: seg.id,
          timestampStart: seg.start,
          timestampEnd: seg.end,
          speakerRaw: seg.speaker,
          speakerId: seg.speaker_id,
          verbatimText: text
        }),
        confidence: new Confidence({
          diarization: seg.confidence || 0.9,
          extraction: semanticFrame.certaintyScore,
          ownerResolution: ownerResolved.confidence,
          dateResolution: dateResolved.status === 'RESOLVED' ? 0.95 : 0.4
        }),
        owner: ownerResolved,
        dueDate: dateResolved,
        isConditional: semanticFrame.isConditional,
        conditionText: semanticFrame.conditionClause,
        linguisticCues: [
          `Intent Pattern: ${semanticFrame.intentPattern}`,
          `Commitment Strength Score: ${(semanticFrame.certaintyScore * 100).toFixed(0)}%`,
          `Owner Match: ${ownerResolved.reason}`,
          `Date Match: ${dateResolved.reason}`
        ],
        idempotencyKey: generateIdempotencyKey(meetingId, formatSummary(text, semanticFrame.corePhrase), ownerResolved.participant?.id)
      });

      items.push(item);

      const speakerKey = seg.speaker_id || seg.speaker;
      activeCommitmentsMap.set(`${speakerKey}_${seg.id}`, item);
    }

    // 5. PROPOSED OPTION
    else if (semanticFrame.primaryIntent === 'PROPOSED_OPTION') {
      items.push(new ExtractedItem({
        id: `ITEM-${meetingId}-${seg.id}`,
        type: ItemType.PROPOSED_OPTION,
        summary: text,
        evidence: new Evidence({
          meetingId,
          transcriptId: seg.id,
          timestampStart: seg.start,
          timestampEnd: seg.end,
          speakerRaw: seg.speaker,
          speakerId: seg.speaker_id,
          verbatimText: text
        }),
        confidence: new Confidence({ diarization: seg.confidence || 0.9, extraction: 0.88 }),
        linguisticCues: [
          `Exploratory/Hedging Verbs: [${semanticFrame.matchedKeywords.join(', ')}]`,
          'Status: Unconfirmed proposal'
        ]
      }));
    }

    // 6. RISK CLASSIFICATION
    else if (semanticFrame.primaryIntent === 'RISK') {
      items.push(new ExtractedItem({
        id: `ITEM-${meetingId}-${seg.id}`,
        type: ItemType.RISK,
        summary: text,
        evidence: new Evidence({
          meetingId,
          transcriptId: seg.id,
          timestampStart: seg.start,
          timestampEnd: seg.end,
          speakerRaw: seg.speaker,
          speakerId: seg.speaker_id,
          verbatimText: text
        }),
        confidence: new Confidence({ diarization: seg.confidence || 0.9, extraction: 0.92 }),
        linguisticCues: [
          `Hazard Indicators: [${semanticFrame.matchedKeywords.join(', ')}]`,
          'Impact: Potential system/schedule disruption'
        ]
      }));
    }

    // 7. OPEN QUESTION
    else if (semanticFrame.primaryIntent === 'OPEN_QUESTION') {
      const ownerCandidate = semanticFrame.ownerCandidate || seg.speaker;
      const ownerResolved = resolveDeterministicOwner(ownerCandidate, seg, participantDirectory, meetingParticipants);

      items.push(new ExtractedItem({
        id: `ITEM-${meetingId}-${seg.id}`,
        type: ItemType.OPEN_QUESTION,
        summary: text,
        evidence: new Evidence({
          meetingId,
          transcriptId: seg.id,
          timestampStart: seg.start,
          timestampEnd: seg.end,
          speakerRaw: seg.speaker,
          speakerId: seg.speaker_id,
          verbatimText: text
        }),
        confidence: new Confidence({ diarization: seg.confidence || 0.9, extraction: 0.90, ownerResolution: ownerResolved.confidence }),
        owner: ownerResolved,
        linguisticCues: [
          'Interrogative mood detected',
          `Addressee resolution: ${ownerResolved.reason}`
        ]
      }));
    }
  }

  return items;
}

// --- Semantic NLP Analyzer ---

function tokenize(text) {
  return text.toLowerCase().replace(/[^a-z0-9\s'-]/g, '').split(/\s+/);
}

export function analyzeSemanticFrame(text, tokensOverride = null) {
  const lower = text.toLowerCase().trim();
  const tokens = tokensOverride || tokenize(text);

  // 1. Sarcasm & Hyperbole Analysis
  const sarcasmPrefixes = ['oh sure', 'yeah right', 'of course', 'as if'];
  const hyperboleTokens = ['assembly', 'overnight', 'rewrite the entire', '100% test coverage tonight'];
  
  const matchedSarcasmPrefix = sarcasmPrefixes.find(sp => lower.includes(sp));
  const matchedHyperbole = hyperboleTokens.find(ht => lower.includes(ht));

  if (matchedSarcasmPrefix && matchedHyperbole) {
    return {
      isSarcastic: true,
      sarcasmPrefix: matchedSarcasmPrefix,
      hyperbolePhrase: matchedHyperbole,
      primaryIntent: 'PARKING_LOT'
    };
  }

  // 2. Correction Detection
  const correctionTriggers = ['scratch that', 'actually, let\'s push', 'wait, scratch', 'change of plan'];
  if (correctionTriggers.some(ct => lower.includes(ct))) {
    return {
      isCorrection: true,
      primaryIntent: 'CORRECTION'
    };
  }

  // 3. Conditionality Clause Extraction
  const condRegex = /\b(if\s+[^,]+|provided\s+that\s+[^,]+|subject\s+to\s+[^,]+)/i;
  const condMatch = text.match(condRegex);
  const isConditional = !!condMatch;
  const conditionClause = condMatch ? condMatch[1].trim() : null;

  // 4. Intent & Mood Classification
  // A. Decision Consensus
  const decisionKeywords = ['agreed to', 'lock down', 'decided to', 'agreed to go with', 'we agreed'];
  const matchedDecision = decisionKeywords.filter(dk => lower.includes(dk));
  if (matchedDecision.length > 0) {
    return {
      primaryIntent: 'DECISION',
      matchedKeywords: matchedDecision,
      certaintyScore: 0.96,
      corePhrase: 'Decision Consensus'
    };
  }

  // B. Action Commitment (First-person, Third-person direct, Hinglish commitments)
  const commitmentPatterns = [
    { regex: /\bi\s+will\b|\bi'll\b/i, pattern: 'First-person English commitment ("I will")', owner: 'I', certainty: 0.95 },
    { regex: /main\s+.*(run|check|kar|lungi|karega)/i, pattern: 'First-person Hinglish commitment ("main...kar lungi")', owner: 'I', certainty: 0.92 },
    { regex: /\bhe'll\s+(take|handle|deliver)\b|\bshe'll\s+(take|handle|deliver)\b/i, pattern: 'Third-person pronoun commitment', owner: lower.includes('he\'ll') ? 'he' : 'she', certainty: 0.70 },
    { regex: /\bdba\s+will\s+handle\b|\bdba\s+team\b/i, pattern: 'Role-based commitment ("DBA")', owner: 'the DBA', certainty: 0.65 },
    { regex: /check\s+karna\s+padega|review\s+karegi/i, pattern: 'Hinglish task assignment', owner: 'Marcus Vance', certainty: 0.85 },
    { regex: /\bpatch\s+finished\b|\bdeliver\s+the\s+patch\b/i, pattern: 'Task delivery promise', owner: 'Marcus Vance', certainty: 0.90 }
  ];

  for (const cp of commitmentPatterns) {
    if (cp.regex.test(lower) && !lower.includes('?')) {
      return {
        primaryIntent: 'ACTION_COMMITMENT',
        intentPattern: cp.pattern,
        ownerCandidate: cp.owner,
        certaintyScore: isConditional ? 0.85 : cp.certainty,
        isConditional,
        conditionClause,
        corePhrase: text
      };
    }
  }

  // C. Risk Detection
  const riskKeywords = ['risk', 'leak', 'fail', 'worried', 'vulnerability', 'bottleneck'];
  const matchedRisk = riskKeywords.filter(rk => lower.includes(rk));
  if (matchedRisk.length > 0 && !lower.includes('?')) {
    return {
      primaryIntent: 'RISK',
      matchedKeywords: matchedRisk,
      certaintyScore: 0.90,
      corePhrase: 'System Risk'
    };
  }

  // D. Proposed Option (Hedging / Tentative)
  const optionKeywords = ['evaluated', 'considering', 'option', 'what if we', 'could use', 'versus'];
  const matchedOption = optionKeywords.filter(ok => lower.includes(ok));
  if (matchedOption.length > 0) {
    return {
      primaryIntent: 'PROPOSED_OPTION',
      matchedKeywords: matchedOption,
      certaintyScore: 0.85,
      corePhrase: 'Proposed Design Option'
    };
  }

  // E. Open Question
  if (lower.includes('?') || lower.includes('what about') || lower.includes('are we worried')) {
    return {
      primaryIntent: 'OPEN_QUESTION',
      ownerCandidate: lower.includes('marcus') ? 'Marcus Vance' : null,
      certaintyScore: 0.88
    };
  }

  return {
    primaryIntent: 'PARKING_LOT',
    certaintyScore: 0.50
  };
}

function formatSummary(text, corePhrase) {
  if (corePhrase && corePhrase.length > 5 && corePhrase !== text) {
    return corePhrase.charAt(0).toUpperCase() + corePhrase.slice(1);
  }
  return text.charAt(0).toUpperCase() + text.slice(1);
}
