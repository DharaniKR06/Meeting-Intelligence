/**
 * Deterministic Date Resolver Module
 * Resolves relative dates ("next Thursday", "end of sprint", "by Friday")
 * against the meeting date and business calendar. Never invents a date.
 */

import { UnresolvedState } from './schema.js';

export function resolveDeterministicDate(rawText, meetingDateStr, calendarData) {
  if (!rawText || typeof rawText !== 'string') {
    return {
      status: UnresolvedState.UNRESOLVED_DATE,
      isoDate: null,
      rawText: rawText || '',
      reason: 'No explicit date phrase found in transcript'
    };
  }

  const normalized = rawText.toLowerCase().trim();
  const baseDate = new Date(meetingDateStr + 'T00:00:00Z');

  if (isNaN(baseDate.getTime())) {
    return {
      status: UnresolvedState.UNRESOLVED_DATE,
      isoDate: null,
      rawText: rawText,
      reason: 'Invalid base meeting date provided'
    };
  }

  // 1. Explicit Sprint Resolution
  if (normalized.includes('end of sprint') || normalized.includes('end of sprint 4')) {
    const sprintInfo = calendarData?.base_calendar?.sprints?.['Sprint 4'];
    if (sprintInfo?.end) {
      return {
        status: 'RESOLVED',
        isoDate: sprintInfo.end,
        rawText: rawText,
        reason: `Resolved via Sprint 4 calendar ending on ${sprintInfo.end}`
      };
    }
  }

  if (normalized.includes('end of sprint 5')) {
    const sprintInfo = calendarData?.base_calendar?.sprints?.['Sprint 5'];
    if (sprintInfo?.end) {
      return {
        status: 'RESOLVED',
        isoDate: sprintInfo.end,
        rawText: rawText,
        reason: `Resolved via Sprint 5 calendar ending on ${sprintInfo.end}`
      };
    }
  }

  // Helper for day of week (0 = Sun, 1 = Mon, ..., 6 = Sat)
  const daysOfWeek = {
    sunday: 0, sun: 0,
    monday: 1, mon: 1,
    tuesday: 2, tue: 2, tuesday: 2,
    wednesday: 3, wed: 3,
    thursday: 4, thu: 4, thurs: 4,
    friday: 5, fri: 5,
    saturday: 6, sat: 6
  };

  const baseDay = baseDate.getUTCDay();

  // 2. Relative Days: "next Thursday", "next Wednesday", "by Friday", "by Monday"
  for (const [dayName, targetDayNum] of Object.entries(daysOfWeek)) {
    if (normalized.includes(dayName)) {
      let daysAhead = 0;
      if (normalized.includes('next')) {
        // "next Thursday" -> next week's Thursday
        daysAhead = (targetDayNum - baseDay + 7) % 7;
        if (daysAhead === 0) daysAhead = 7;
      } else {
        // "by Friday", "by Monday"
        daysAhead = (targetDayNum - baseDay + 7) % 7;
        if (daysAhead === 0 && (normalized.includes('by') || normalized.includes('this'))) {
          daysAhead = 0; // Same day if today is Friday
        } else if (daysAhead === 0) {
          daysAhead = 7;
        }
      }

      const resolved = new Date(baseDate);
      resolved.setUTCDate(baseDate.getUTCDate() + daysAhead);
      const isoStr = resolved.toISOString().split('T')[0];

      return {
        status: 'RESOLVED',
        isoDate: isoStr,
        rawText: rawText,
        reason: `Calculated from base date ${meetingDateStr} + ${daysAhead} days (${dayName})`
      };
    }
  }

  // 3. Absolute ISO Date parsing
  const isoMatch = rawText.match(/\b\d{4}-\d{2}-\d{2}\b/);
  if (isoMatch) {
    return {
      status: 'RESOLVED',
      isoDate: isoMatch[0],
      rawText: rawText,
      reason: 'Explicit ISO date string matched'
    };
  }

  // 4. Relative offset ("in 3 days")
  const inDaysMatch = normalized.match(/in (\d+) days?/);
  if (inDaysMatch) {
    const numDays = parseInt(inDaysMatch[1], 10);
    const resolved = new Date(baseDate);
    resolved.setUTCDate(baseDate.getUTCDate() + numDays);
    const isoStr = resolved.toISOString().split('T')[0];
    return {
      status: 'RESOLVED',
      isoDate: isoStr,
      rawText: rawText,
      reason: `Base date ${meetingDateStr} + ${numDays} days`
    };
  }

  // 5. Unresolved / Vague expression
  return {
    status: UnresolvedState.UNRESOLVED_DATE,
    isoDate: null,
    rawText: rawText,
    reason: 'Vague date phrase or no agreement recorded (never guessing)'
  };
}
