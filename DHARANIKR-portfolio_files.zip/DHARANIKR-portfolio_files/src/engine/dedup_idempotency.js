/**
 * Idempotency, Duplicate Detection & Audit Trail Engine
 */

export function generateIdempotencyKey(meetingId, summaryText, ownerId = 'UNRESOLVED') {
  const normSummary = (summaryText || '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '')
    .substring(0, 40);
  const rawKey = `${meetingId}_${normSummary}_${ownerId}`;
  
  // Simple deterministic hash calculation for browser/node cross-compatibility
  let hash = 0;
  for (let i = 0; i < rawKey.length; i++) {
    const char = rawKey.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0; // Convert to 32bit integer
  }
  return `KEY-${meetingId}-${Math.abs(hash).toString(36)}`;
}

export function detectDuplicates(newItem, existingTasks = []) {
  if (!newItem || !existingTasks || existingTasks.length === 0) {
    return null;
  }

  const normNew = (newItem.summary || '').toLowerCase();

  for (const task of existingTasks) {
    const normExisting = (task.title || task.summary || '').toLowerCase();
    
    // Check exact or high keyword similarity
    if (normNew === normExisting) {
      return {
        isDuplicate: true,
        matchedTaskId: task.id,
        matchedTaskTitle: task.title,
        confidence: 1.0,
        reason: `Exact duplicate match found with existing Task #${task.id}`
      };
    }

    // Keyword overlap calculation
    const wordsNew = new Set(normNew.split(/\s+/).filter(w => w.length > 3));
    const wordsExisting = new Set(normExisting.split(/\s+/).filter(w => w.length > 3));
    
    if (wordsNew.size > 0 && wordsExisting.size > 0) {
      const intersection = new Set([...wordsNew].filter(x => wordsExisting.has(x)));
      const similarity = intersection.size / Math.max(wordsNew.size, wordsExisting.size);
      
      if (similarity > 0.65) {
        return {
          isDuplicate: true,
          matchedTaskId: task.id,
          matchedTaskTitle: task.title,
          confidence: +(similarity.toFixed(2)),
          reason: `High similarity (${Math.round(similarity * 100)}%) with Task #${task.id}: "${task.title}"`
        };
      }
    }
  }

  return null;
}

export class AuditLogger {
  constructor() {
    this.logs = [];
  }

  logEvent({ action, meetingId, runId, itemId, taskId, confirmedBy, details }) {
    const entry = {
      id: `AUD-${Date.now()}-${Math.floor(Math.random()*1000)}`,
      timestamp: new Date().toISOString(),
      action, // e.g. 'TASK_CREATED', 'TASK_CONFIRMED', 'OWNER_OVERRIDDEN', 'DATE_OVERRIDDEN'
      meetingId,
      runId,
      itemId,
      taskId,
      confirmedBy: confirmedBy || 'Human Reviewer (UI)',
      details
    };
    this.logs.push(entry);
    return entry;
  }

  getLogsForMeeting(meetingId) {
    return this.logs.filter(l => l.meetingId === meetingId);
  }

  getAllLogs() {
    return [...this.logs];
  }
}
