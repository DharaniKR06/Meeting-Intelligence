/**
 * Upgraded Frontend Controller for Meeting Intelligence Workflow System
 */

import directoryData from './data/participant_directory.json' with { type: 'json' };
import glossaryData from './data/project_glossary.json' with { type: 'json' };
import testMeetings from './data/test_meetings.json' with { type: 'json' };
import groundTruth from './data/ground_truth.json' with { type: 'json' };

import { extractMeetingItems, analyzeSemanticFrame } from './engine/extraction.js';
import { resolveDeterministicDate } from './engine/date_resolver.js';
import { resolveDeterministicOwner } from './engine/owner_resolver.js';
import { detectDuplicates } from './engine/dedup_idempotency.js';
import { MockTaskAPI } from './engine/task_api_mock.js';
import { runFullEvaluation } from './engine/evaluator.js';

// Application State
const state = {
  currentMeetingId: 'MTG-001',
  currentMeeting: null,
  extractedItems: [],
  activeConfirmItem: null,
  taskApi: new MockTaskAPI(),
  isPlayingAudio: false,
  audioTimer: null,
  audioProgressPct: 0
};

// DOM Element Selectors
const meetingSelect = document.getElementById('meeting-select');
const btnReprocess = document.getElementById('btn-reprocess');
const btnRunEval = document.getElementById('btn-run-eval');
const btnClearTasks = document.getElementById('btn-clear-tasks');

const btnToggleCustom = document.getElementById('btn-toggle-custom');
const customIngestContainer = document.getElementById('custom-ingest-container');
const btnCloseCustom = document.getElementById('btn-close-custom');
const customTranscriptText = document.getElementById('custom-transcript-text');
const btnParseCustom = document.getElementById('btn-parse-custom');

const btnAudioPlay = document.getElementById('btn-audio-play');
const audioTimeDisplay = document.getElementById('audio-time-display');
const waveformProgress = document.getElementById('waveform-progress');

const transcriptContainer = document.getElementById('transcript-container');
const itemsContainer = document.getElementById('items-container');
const meetingBadge = document.getElementById('meeting-badge');
const itemsCountBadge = document.getElementById('items-count-badge');

const confirmModalOverlay = document.getElementById('confirm-modal-overlay');
const btnCloseModal = document.getElementById('btn-close-modal');
const btnCancelTask = document.getElementById('btn-cancel-task');
const btnDispatchTask = document.getElementById('btn-dispatch-task');

const modalEvidenceQuote = document.getElementById('modal-evidence-quote');
const modalInputTitle = document.getElementById('modal-input-title');
const modalSelectOwner = document.getElementById('modal-select-owner');
const modalInputDate = document.getElementById('modal-input-date');
const modalSelectProject = document.getElementById('modal-select-project');
const modalCheckboxConditional = document.getElementById('modal-checkbox-conditional');
const conditionClauseContainer = document.getElementById('condition-clause-container');
const modalInputCondition = document.getElementById('modal-input-condition');
const duplicateWarningBanner = document.getElementById('duplicate-warning-banner');
const duplicateWarningText = document.getElementById('duplicate-warning-text');

const taskTableBody = document.getElementById('task-table-body');
const auditFeedContainer = document.getElementById('audit-feed-container');

// Playground selectors
const playgroundSarcasmInput = document.getElementById('playground-sarcasm-input');
const btnTestSarcasm = document.getElementById('btn-test-sarcasm');
const playgroundSarcasmResult = document.getElementById('playground-sarcasm-result');
const playgroundDatePhrase = document.getElementById('playground-date-phrase');
const playgroundOwnerPhrase = document.getElementById('playground-owner-phrase');
const btnTestResolvers = document.getElementById('btn-test-resolvers');
const playgroundResolverResult = document.getElementById('playground-resolver-result');

// Tab Navigation
document.querySelectorAll('.nav-tab').forEach(tabBtn => {
  tabBtn.addEventListener('click', () => {
    document.querySelectorAll('.nav-tab').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

    tabBtn.classList.add('active');
    const tabId = tabBtn.getAttribute('data-tab');
    document.getElementById(tabId).classList.add('active');
  });
});

// Initialize Application
function init() {
  populateOwnerOptions();
  loadMeeting(state.currentMeetingId);
  setupEventListeners();
  runEvaluationHarness();
}

function populateOwnerOptions() {
  modalSelectOwner.innerHTML = `
    <option value="UNRESOLVED_OWNER">⚠️ Unresolved Owner (Requires Manual Selection)</option>
    ${directoryData.map(p => `<option value="${p.id}">${p.name} — ${p.role} (${p.email})</option>`).join('')}
  `;
}

function loadMeeting(meetingId) {
  state.currentMeetingId = meetingId;
  stopAudioSimulation();

  if (meetingId === 'CUSTOM') {
    customIngestContainer.style.display = 'block';
    return;
  }

  customIngestContainer.style.display = 'none';
  state.currentMeeting = testMeetings.find(m => m.id === meetingId);
  meetingBadge.textContent = `${state.currentMeeting.id} (${state.currentMeeting.diarization_quality} DIARIZATION)`;
  
  renderTranscript(state.currentMeeting);

  // Run Pipeline Extraction
  state.extractedItems = extractMeetingItems(state.currentMeeting, directoryData, glossaryData);
  renderExtractedItems(state.extractedItems);
}

function renderTranscript(meeting) {
  transcriptContainer.innerHTML = meeting.transcript.map(line => {
    const isLowConf = typeof line.confidence === 'number' && line.confidence < 0.70;
    return `
      <div class="transcript-line" id="line-${line.id}">
        <div class="line-meta">
          <span class="speaker-badge">${line.speaker}</span>
          <div>
            <span class="time-stamp">[${line.start} - ${line.end}]</span>
            <span class="diar-conf ${isLowConf ? 'low' : ''}">Conf: ${Math.round((line.confidence || 0.9)*100)}%</span>
          </div>
        </div>
        <div class="line-text">"${line.text}"</div>
      </div>
    `;
  }).join('');
}

function renderExtractedItems(items) {
  itemsCountBadge.textContent = `${items.length} Extracted Items`;
  
  if (items.length === 0) {
    itemsContainer.innerHTML = `<div style="color: var(--text-dim); padding: 20px; text-align: center;">No actionable items found in transcript.</div>`;
    return;
  }

  itemsContainer.innerHTML = items.map(item => {
    const isAction = item.type === 'ACTION_COMMITMENT';
    const isDecision = item.type === 'DECISION';
    const isOption = item.type === 'PROPOSED_OPTION';
    const isQuestion = item.type === 'OPEN_QUESTION';
    const isRisk = item.type === 'RISK';
    const isParking = item.type === 'PARKING_LOT';

    let badgeClass = 'badge-action';
    if (isDecision) badgeClass = 'badge-decision';
    if (isOption) badgeClass = 'badge-option';
    if (isQuestion) badgeClass = 'badge-question';
    if (isRisk) badgeClass = 'badge-risk';
    if (isParking) badgeClass = 'badge-parking';

    const ownerName = item.owner?.status === 'RESOLVED' 
      ? `${item.owner.participant.name} (${item.owner.participant.role})`
      : `<span class="meta-value unresolved">⚠️ Unresolved Owner</span>`;

    const dueDateVal = item.dueDate?.status === 'RESOLVED'
      ? item.dueDate.isoDate
      : `<span class="meta-value unresolved">⚠️ Unresolved Date</span>`;

    return `
      <div class="item-card" data-item-id="${item.id}">
        <div class="item-card-header">
          <span class="item-type-badge ${badgeClass}">${item.type.replace('_', ' ')}</span>
          <span style="font-size: 11px; color: var(--text-dim);">Conf: ${Math.round(item.confidence.overall * 100)}%</span>
        </div>

        <div class="item-summary">${item.summary}</div>

        <div class="item-meta-grid">
          <div class="meta-slot">
            <span class="meta-label">Proposed Owner</span>
            <span class="meta-value">${ownerName}</span>
          </div>
          <div class="meta-slot">
            <span class="meta-label">Calculated Due Date</span>
            <span class="meta-value">${dueDateVal}</span>
          </div>
        </div>

        ${item.isConditional ? `<div style="font-size: 11px; color: var(--accent-amber); margin-bottom: 8px;">🔸 <strong>Conditional:</strong> ${item.conditionText}</div>` : ''}

        <div class="evidence-quote">"${item.evidence.verbatimText}"</div>

        <div class="cues-list">
          ${item.linguisticCues.map(c => `<div>• ${c}</div>`).join('')}
        </div>

        ${isAction ? `
          <div class="card-actions">
            <button class="btn-confirm-task" onclick="window.openConfirmModal('${item.id}')">
              🛡️ Confirm & Create Task
            </button>
          </div>
        ` : ''}
      </div>
    `;
  }).join('');
}

// Global modal trigger helper
window.openConfirmModal = function(itemId) {
  const item = state.extractedItems.find(i => i.id === itemId);
  if (!item) return;

  state.activeConfirmItem = item;

  // Highlight transcript evidence line
  document.querySelectorAll('.transcript-line').forEach(el => el.classList.remove('highlighted'));
  const lineEl = document.getElementById(`line-${item.evidence.transcriptId}`);
  if (lineEl) {
    lineEl.classList.add('highlighted');
    lineEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  // Populate Modal Fields
  modalEvidenceQuote.textContent = `"${item.evidence.verbatimText}"`;
  modalInputTitle.value = item.summary;

  if (item.owner?.status === 'RESOLVED') {
    modalSelectOwner.value = item.owner.participant.id;
  } else {
    modalSelectOwner.value = 'UNRESOLVED_OWNER';
  }

  if (item.dueDate?.status === 'RESOLVED') {
    modalInputDate.value = item.dueDate.isoDate;
  } else {
    modalInputDate.value = '';
  }

  modalCheckboxConditional.checked = !!item.isConditional;
  if (item.isConditional) {
    conditionClauseContainer.style.display = 'flex';
    modalInputCondition.value = item.conditionText || '';
  } else {
    conditionClauseContainer.style.display = 'none';
    modalInputCondition.value = '';
  }

  // Run Duplicate Detection Check
  const dupResult = detectDuplicates(item, state.taskApi.listTasks());
  if (dupResult && dupResult.isDuplicate) {
    duplicateWarningBanner.style.display = 'flex';
    duplicateWarningText.textContent = `${dupResult.reason}`;
  } else {
    duplicateWarningBanner.style.display = 'none';
  }

  confirmModalOverlay.classList.add('active');
};

function closeModal() {
  confirmModalOverlay.classList.remove('active');
  state.activeConfirmItem = null;
}

function handleDispatchTask() {
  const item = state.activeConfirmItem;
  if (!item) return;

  const ownerId = modalSelectOwner.value;
  if (ownerId === 'UNRESOLVED_OWNER') {
    alert('Please assign a valid owner from the directory before confirming the task!');
    return;
  }

  const dueDate = modalInputDate.value;
  if (!dueDate) {
    alert('Please specify a valid due date before confirming the task!');
    return;
  }

  const selectedOwnerObj = directoryData.find(p => p.id === ownerId);

  const payload = {
    meetingId: item.evidence.meetingId,
    sourceItemId: item.id,
    title: modalInputTitle.value,
    ownerId: ownerId,
    ownerName: selectedOwnerObj ? selectedOwnerObj.name : ownerId,
    dueDate: dueDate,
    project: modalSelectProject.value,
    isConditional: modalCheckboxConditional.checked,
    conditionText: modalCheckboxConditional.checked ? modalInputCondition.value : null,
    evidenceQuote: item.evidence.verbatimText,
    evidenceTimestamp: item.evidence.timestampStart,
    idempotencyKey: item.idempotencyKey,
    humanConfirmed: true, // HARD CONFIRMATION FLAG
    confirmationToken: `CONF-TOK-${Date.now()}`,
    confirmedBy: 'Human Reviewer (UI)'
  };

  try {
    const res = state.taskApi.createTask(payload);
    if (res.status === 'SUCCESS') {
      renderTaskBoard();
      closeModal();
      document.querySelector('[data-tab="tab-tasks"]').click();
    } else if (res.status === 'IDEMPOTENT_SKIPPED') {
      alert(`[IDEMPOTENT REJECTION] ${res.message}`);
      closeModal();
    }
  } catch (err) {
    alert(err.message);
  }
}

function renderTaskBoard() {
  const tasks = state.taskApi.listTasks();
  taskTableBody.innerHTML = tasks.map(t => `
    <tr>
      <td><strong>${t.id}</strong></td>
      <td>${t.title}</td>
      <td>${t.ownerName}</td>
      <td>${t.dueDate}</td>
      <td>${t.project}</td>
      <td>${t.isConditional ? `<span style="color: var(--accent-amber);">Condition: ${t.conditionText}</span>` : 'Unconditional'}</td>
      <td><span style="font-family: monospace; font-size: 11px;">${t.idempotencyKey}</span></td>
    </tr>
  `).join('');

  if (tasks.length === 0) {
    taskTableBody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-dim);">No confirmed tasks created yet. Use the confirmation workflow to create tasks.</td></tr>`;
  }

  const auditLogs = state.taskApi.getAuditTrail();
  auditFeedContainer.innerHTML = auditLogs.map(log => `
    <div class="audit-card">
      <div class="audit-action">${log.action}</div>
      <div>Task #${log.taskId || 'N/A'} | Meeting: ${log.meetingId}</div>
      <div style="color: var(--text-muted); margin-top: 4px;">${log.details}</div>
      <div style="color: var(--text-dim); font-size: 10px; margin-top: 4px;">Actor: ${log.confirmedBy} @ ${new Date(log.timestamp).toLocaleTimeString()}</div>
    </div>
  `).join('');
}

function runEvaluationHarness() {
  const evalResults = runFullEvaluation(testMeetings, groundTruth, directoryData, glossaryData, state.taskApi);
  
  document.getElementById('metric-precision').textContent = evalResults.overall.actionCommitmentsPrecision.toFixed(2);
  document.getElementById('metric-recall').textContent = evalResults.overall.actionCommitmentsRecall.toFixed(2);
  document.getElementById('metric-owner-acc').textContent = `${evalResults.overall.ownerAccuracyPct}%`;
  document.getElementById('metric-date-acc').textContent = `${evalResults.overall.dueDateAccuracyPct}%`;
  document.getElementById('metric-unsupported').textContent = `${evalResults.overall.unsupportedItemRatePct}%`;
  document.getElementById('metric-effort').textContent = evalResults.overall.confirmationEffortScore.toFixed(1);

  const container = document.getElementById('analysis-cards-container');
  container.innerHTML = Object.entries(evalResults.byMeeting).map(([id, m]) => `
    <div class="analysis-card">
      <h3>${m.meetingTitle} (${id})</h3>
      <div style="font-size: 11px; color: var(--accent-cyan); margin-bottom: 8px;">Diarization Quality: ${m.diarizationQuality} | Language: ${m.language}</div>
      <ul class="analysis-list">
        ${m.failureAnalysis.map(note => `<li>${note}</li>`).join('')}
      </ul>
      <div style="margin-top: 12px; font-weight: 600; font-size: 11px; color: var(--text-muted);">
        Actions Precision: ${m.actionPrecision} | Recall: ${m.actionRecall}
      </div>
    </div>
  `).join('');
}

// Audio Player Simulation Ticker
function toggleAudioSimulation() {
  if (state.isPlayingAudio) {
    stopAudioSimulation();
  } else {
    state.isPlayingAudio = true;
    btnAudioPlay.textContent = '⏸';
    state.audioTimer = setInterval(() => {
      state.audioProgressPct = (state.audioProgressPct + 2) % 100;
      waveformProgress.style.width = `${state.audioProgressPct}%`;
      const currentSeconds = Math.floor((state.audioProgressPct / 100) * 240);
      const mins = String(Math.floor(currentSeconds / 60)).padStart(2, '0');
      const secs = String(currentSeconds % 60).padStart(2, '0');
      audioTimeDisplay.textContent = `${mins}:${secs} / 04:00`;
    }, 200);
  }
}

function stopAudioSimulation() {
  state.isPlayingAudio = false;
  btnAudioPlay.textContent = '▶';
  if (state.audioTimer) clearInterval(state.audioTimer);
}

// Playground Tests
function runPlaygroundSarcasmTest() {
  const text = playgroundSarcasmInput.value;
  const frame = analyzeSemanticFrame(text);
  playgroundSarcasmResult.innerHTML = `
    <div><strong>Input:</strong> "${text}"</div>
    <div style="color: ${frame.isSarcastic ? 'var(--accent-rose)' : 'var(--accent-emerald)'}; margin-top: 6px;">
      Primary Intent: <strong>${frame.primaryIntent}</strong>
    </div>
    ${frame.isSarcastic ? `
      <div>Sarcasm Prefix: ${frame.sarcasmPrefix}</div>
      <div>Hyperbole Phrase: ${frame.hyperbolePhrase}</div>
      <div>Status: <strong>Filtered out (Discarded from Task Queue)</strong></div>
    ` : `
      <div>Matched Keywords: ${frame.matchedKeywords ? frame.matchedKeywords.join(', ') : 'N/A'}</div>
    `}
  `;
}

function runPlaygroundResolverTest() {
  const datePhrase = playgroundDatePhrase.value;
  const ownerPhrase = playgroundOwnerPhrase.value;

  const dateRes = resolveDeterministicDate(datePhrase, '2026-09-11', glossaryData);
  const ownerRes = resolveDeterministicOwner(ownerPhrase, { speaker: 'David Kim', confidence: 0.95 }, directoryData, ['USR-001', 'USR-002', 'USR-005']);

  playgroundResolverResult.innerHTML = `
    <div style="margin-bottom: 8px;"><strong>Date Phrase:</strong> "${datePhrase}"</div>
    <div>Status: <span style="color: ${dateRes.status === 'RESOLVED' ? 'var(--accent-emerald)' : 'var(--accent-amber)'}">${dateRes.status}</span></div>
    <div>ISO Date: ${dateRes.isoDate || 'null'}</div>
    <div>Reason: ${dateRes.reason}</div>

    <hr style="border-color: var(--border-color); margin: 10px 0;">

    <div style="margin-bottom: 8px;"><strong>Owner Candidate:</strong> "${ownerPhrase}"</div>
    <div>Status: <span style="color: ${ownerRes.status === 'RESOLVED' ? 'var(--accent-emerald)' : 'var(--accent-amber)'}">${ownerRes.status}</span></div>
    <div>Assigned Directory Person: ${ownerRes.participant ? ownerRes.participant.name : 'null'}</div>
    <div>Reason: ${ownerRes.reason}</div>
  `;
}

function setupEventListeners() {
  meetingSelect.addEventListener('change', (e) => loadMeeting(e.target.value));
  btnReprocess.addEventListener('click', () => loadMeeting(state.currentMeetingId));
  btnRunEval.addEventListener('click', () => {
    runEvaluationHarness();
    document.querySelector('[data-tab="tab-evaluation"]').click();
  });

  btnToggleCustom.addEventListener('click', () => {
    customIngestContainer.style.display = customIngestContainer.style.display === 'none' ? 'block' : 'none';
  });
  btnCloseCustom.addEventListener('click', () => customIngestContainer.style.display = 'none');

  btnParseCustom.addEventListener('click', () => {
    try {
      const raw = JSON.parse(customTranscriptText.value);
      const customMtg = {
        id: 'MTG-CUSTOM',
        title: 'Custom User Uploaded Meeting',
        date: '2026-09-11',
        diarization_quality: 'HIGH',
        language: 'en-US',
        participants_present: ['USR-001', 'USR-002', 'USR-003'],
        transcript: raw
      };
      state.currentMeeting = customMtg;
      meetingBadge.textContent = 'CUSTOM MEETING';
      renderTranscript(customMtg);
      state.extractedItems = extractMeetingItems(customMtg, directoryData, glossaryData);
      renderExtractedItems(state.extractedItems);
      customIngestContainer.style.display = 'none';
    } catch (e) {
      alert('Invalid JSON transcript format. Please provide valid JSON array of transcript segments.');
    }
  });

  btnAudioPlay.addEventListener('click', toggleAudioSimulation);

  btnClearTasks.addEventListener('click', () => {
    state.taskApi.reset();
    renderTaskBoard();
  });

  btnCloseModal.addEventListener('click', closeModal);
  btnCancelTask.addEventListener('click', closeModal);
  btnDispatchTask.addEventListener('click', handleDispatchTask);

  modalCheckboxConditional.addEventListener('change', (e) => {
    conditionClauseContainer.style.display = e.target.checked ? 'flex' : 'none';
  });

  btnTestSarcasm.addEventListener('click', runPlaygroundSarcasmTest);
  btnTestResolvers.addEventListener('click', runPlaygroundResolverTest);
}

document.addEventListener('DOMContentLoaded', () => {
  init();
  runPlaygroundSarcasmTest();
  runPlaygroundResolverTest();
});
